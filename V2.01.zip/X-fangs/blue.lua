local S = minetest.get_translator(minetest.get_current_modname())

--the suit
armor:register_armor(":Xfangs:blue_fang", {
    description = S("Blue fang's suit"),
    inventory_image = "blue_fang_inv.png",
    groups = {armor_torso=1, armor_heal=5000, armor=5000, armor_fire=1, physics_jump=2, physics_speed=5},
    damage_groups = {cracky=0, snapp=0, level=6},
})

--crafting

minetest.register_craft({
    output = "Xfangs:blue_fang",
    recipe = {
        {"Xfangs:graphn_nfiber", "", "Xfangs:graphn_nfiber"},
        {"dye:blue", "default:steel_ingot", "dye:blue"},
        {"Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber"},
    },
})

