local S = minetest.get_translator(minetest.get_current_modname())

--the suit
armor:register_armor(":Xfangs:silver_fang", {
    description = S("Silver fang's suit"),
    inventory_image = "silver_fang_inv.png",
    groups = {armor_torso=1, armor_heal=5000, armor=5000, armor_fire=1, physics_jump=2.5, physics_speed=7},
    damage_groups = {cracky=0, snapp=0, level=6},
})

--crafting

minetest.register_craft({
    output = "Xfangs:silver_fang",
    recipe = {
        {"Xfangs:graphn_nfiber", "", "Xfangs:graphn_nfiber"},
        {"default:tin_ingot", "default:steel_ingot", "default:tin_ingot"},
        {"Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber"},
    },
})

