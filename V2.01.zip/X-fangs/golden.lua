local S = minetest.get_translator(minetest.get_current_modname())

--the suit
armor:register_armor(":Xfangs:golden_fang", {
    description = S("Golden fang's suit"),
    inventory_image = "golden_fang_inv.png",
    groups = {armor_torso=1, armor_heal=5000, armor=5000, armor_fire=1, physics_jump=4, physics_speed=12, not_in_creative_inventory = 1},
    damage_groups = {cracky=0, snapp=0, level=6},
})

--crafting

minetest.register_craft({
    output = "Xfangs:golden_fang",
    recipe = {
        {"Xfangs:graphn_nfiber", "", "Xfangs:graphn_nfiber"},
        {"default:tin_ingot", "default:gold_ingot", "default:steel_ingot"},
        {"Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber"},
    },
})

