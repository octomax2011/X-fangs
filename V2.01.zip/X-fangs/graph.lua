local S = minetest.get_translator(minetest.get_current_modname())

core.register_craftitem(":Xfangs:graphite_D", {
    description = "graphite diamond",
    inventory_image = "graphD.png"
})

core.register_craftitem(":Xfangs:graphn_nfiber", {
    description = "graphene nano fiber",
    inventory_image = "graphFiber.png"
})

--crafting

minetest.register_craft({
    output = "Xfangs:graphite_D",
    recipe = {
        {"default:coal_block", "", "default:coal_block"},
        {"", "default:diamond", ""},
        {"default:coal_block", "", "default:coal_block"},
        
    },
})


minetest.register_craft({
    output = "Xfangs:graphn_nfiber",
    recipe = {
        {"Xfangs:graphite_D", "", ""},
        {"", "Xfangs:graphite_D", ""},
        {"", "Xfangs:graphite_D", "Xfangs:graphite_D"},
        
    }
})