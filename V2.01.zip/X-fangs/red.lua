local S = minetest.get_translator(minetest.get_current_modname())

--the suit
armor:register_armor(":Xfangs:red_fang", {
    description = S("Red fang's suit"),
    inventory_image = "red_fang_inv.png",
    groups = {armor_torso=1, armor_heal=5000, armor=5000, armor_fire=1, physics_jump=3, physics_speed=6},
    damage_groups = {cracky=0, snapp=0, level=6},
})

--crafting

minetest.register_craft({
    output = "Xfangs:red_fang",
    recipe = {
        {"Xfangs:graphn_nfiber", "", "Xfangs:graphn_nfiber"},
        {"dye:red", "default:steel_ingot", "dye:red"},
        {"Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber", "Xfangs:graphn_nfiber"},
    },
})

