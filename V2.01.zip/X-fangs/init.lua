local modname = minetest.get_current_modname()
local modpath = minetest.get_modpath(modname)
local S = minetest.get_translator(minetest.get_current_modname())

dofile(modpath .. "/golden.lua")
dofile(modpath .. "/silver.lua")
dofile(modpath .. "/red.lua")
dofile(modpath .. "/blue.lua")
dofile(modpath .. "/graph.lua")